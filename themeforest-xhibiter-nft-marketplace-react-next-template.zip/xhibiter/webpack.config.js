module.exports = {
	devtool: 'source-map',
};

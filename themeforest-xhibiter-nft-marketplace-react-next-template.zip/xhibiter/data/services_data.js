export const services_data = [
	{
		title: 'NFT Consultant Analytics',
		desc: "Once you've set up your wallet of choice, connect it to OpenSeaby clicking the NFT Marketplacein the top right corner.",
		id: '0NFT Consultant Analytics',
		icon: 'service-ico-1',
	},
	{
		title: 'NFT Marketing',
		desc: "Once you've set up your wallet of choice, connect it to OpenSeaby clicking the NFT Marketplacein the top right corner.",
		id: '1NFT Marketing',
		icon: 'service-ico-2',
	},
	{
		title: 'NFT Strategy',
		desc: "Once you've set up your wallet of choice, connect it to OpenSeaby clicking the NFT Marketplacein the top right corner.",
		id: '2NFT Strategy',
		icon: 'service-ico-3',
	},
	{
		title: 'NFT Technology',
		desc: "Once you've set up your wallet of choice, connect it to OpenSeaby clicking the NFT Marketplacein the top right corner.",
		id: '3NFT Technology',
		icon: 'service-ico-4',
	},
	{
		title: 'Advisers & Intermediaries',
		desc: "Once you've set up your wallet of choice, connect it to OpenSeaby clicking the NFT Marketplacein the top right corner.",
		id: '4Advisers & Intermediaries',
		icon: 'service-ico-5',
	},
	{
		title: 'ICO Token',
		desc: "Once you've set up your wallet of choice, connect it to OpenSeaby clicking the NFT Marketplacein the top right corner.",
		id: '5ICO Token',
		icon: 'service-ico-6',
	},
];

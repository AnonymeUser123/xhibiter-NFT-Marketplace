export const features_carousel_data = [
  {
    title: "Build a driven community",
    desc: "With millions in transactions since 2017, we’ll help you generate revenue on our platform ⁠— from direct sales to secondary sales",
    img: "/images/features/features-img-1.png",
    id: 1,
  },
  {
    title: "Create awareness & knowledge",
    desc: "With millions in transactions since 2017, we’ll help you generate revenue on our platform ⁠— from direct sales to secondary sales",
    img: "/images/features/features-img-2.png",
    id: 2,
  },
  {
    title: "Enhancing global security",
    desc: "With millions in transactions since 2017, we’ll help you generate revenue on our platform ⁠— from direct sales to secondary sales",
    img: "/images/features/features-img-3.png",
    id: 3,
  },
  {
    title: "Generate financial Investment",
    desc: "With millions in transactions since 2017, we’ll help you generate revenue on our platform ⁠— from direct sales to secondary sales",
    img: "/images/features/features-img-4.png",
    id: 4,
  },
];

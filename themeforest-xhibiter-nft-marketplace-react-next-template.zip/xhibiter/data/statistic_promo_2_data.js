export const statistic_promo_2_data = [
	{
		id: '1',
		img: '/images/nft-game/robot_large_1.png',
	},
	{
		id: '2',
		img: '/images/nft-game/robot_large_2.png',
	},
	{
		id: '3',
		img: '/images/nft-game/robot_large_3.png',
	},
	{
		id: '4',
		img: '/images/nft-game/robot_large_4.png',
	},
];

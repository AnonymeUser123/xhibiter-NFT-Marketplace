export const careers_positions_data = [
	{
		title: 'UI / UX Designer',
		desc: 'We are looking for a full-time Software QA Analyst to be part of our team to ensure the top-notch quality, overall functionality and usability.',
		experience: 'Experience – 3 to 5 years',
		id: 1,
	},
	{
		title: 'Full Stack Engineer',
		desc: 'We are looking for a full-time Software QA Analyst to be part of our team to ensure the top-notch quality, overall functionality and usability.',
		experience: 'Experience – 3 to 5 years',
		id: 2,
	},
	{
		title: 'Content Writer',
		desc: 'We are looking for a full-time Software QA Analyst to be part of our team to ensure the top-notch quality, overall functionality and usability.',
		experience: 'Experience – 1 to 2 years',
		id: 3,
	},
	{
		title: 'React Developer',
		desc: 'We are looking for a full-time Software QA Analyst to be part of our team to ensure the top-notch quality, overall functionality and usability.',
		experience: 'Experience – 3 to 5 years',
		id: 4,
	},
	{
		title: 'Growth Hacker',
		desc: 'We are looking for a full-time Software QA Analyst to be part of our team to ensure the top-notch quality, overall functionality and usability.',
		experience: 'Experience – 3 to 5 years',
		id: 5,
	},
	{
		title: 'Media Marketer',
		desc: 'We are looking for a full-time Software QA Analyst to be part of our team to ensure the top-notch quality, overall functionality and usability.',
		experience: 'Experience – 3 to 5 years',
		id: 6,
	},
];
